export class Grid{
    colName:string;
  }
  