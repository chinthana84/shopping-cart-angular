import { Grid } from "./grid.model";



export class GridOptions{
    colNames?: Grid[];
    datas?:any;

  }
